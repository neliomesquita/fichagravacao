package br.com.fichagravacao.bean;

import br.com.fichagravacao.util.DatabaseUtil;

import jakarta.faces.view.ViewScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;

@ViewScoped
public class RegistroBean {
    private String email;
    private String password;

    // Getters and Setters
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    // Registration Method
    public String register() {
        try {
            DatabaseUtil.createUser(email, password);
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Registration Successful!", null));
            return "login.xhtml"; // Redirect to login page after successful registration
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Registration Failed: " + e.getMessage(), null));
            return null; // Stay on the registration page
        }
    }
    
    public String login() {
        if (DatabaseUtil.validateUser(email, password)) {
            return "dashboard.xhtml"; // Redirect to dashboard on success
        } else {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage("Invalid credentials"));
            return null; // Stay on the login page
        }
    }
}