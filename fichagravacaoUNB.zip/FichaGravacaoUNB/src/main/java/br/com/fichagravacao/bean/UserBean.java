package br.com.fichagravacao.bean;

import br.com.fichagravacao.model.User;
import br.com.fichagravacao.service.UserService;

import jakarta.annotation.PostConstruct;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import java.util.List;


@ViewScoped
public class UserBean {

    @Inject
    private UserService userService;

    private User user = new User();
    private List<User> userList;

    @PostConstruct
    public void init() {
        userList = userService.findAll();
    }

    public void save() {
        userService.create(user);
        user = new User();
        userList = userService.findAll();
    }

    public void update() {
        userService.update(user);
        user = new User();
        userList = userService.findAll();
    }

    public void delete(Long id) {
        userService.delete(id);
        userList = userService.findAll();
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public List<User> getUserList() {
        return userList;
    }
}