package br.com.fichagravacao.bean;

import br.com.fichagravacao.util.DatabaseUtil;

import jakarta.faces.view.ViewScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext; 
import java.io.IOException;


@ViewScoped
public class LoginBean {
    private String email;
    private String password;

    // Getters and Setters
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    // Login Method
    public String login() {
        if (DatabaseUtil.validateUser(email, password)) {
            return "dashboard.xhtml"; // Redirect to dashboard on success
        } else {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage("Invalid credentials"));
            return null; // Stay on the login page
        }
    }

    
    // Logout Method
    public void logout() throws IOException {
        FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
        FacesContext.getCurrentInstance().getExternalContext().redirect("login.xhtml");
    }
}